# import the module
import speech_recognition as sr
import moviepy.editor as mp
import os
import os.path
import sys
import wave
import contextlib
import math
from pydub import AudioSegment
#define the recognizer
r = sr.Recognizer()
audioName = sys.argv[1]
print('Get: ' + sys.argv[1])

# extractAudio-------------------------------------------------------------------------------------------
def changeVideo():
    if(not(os.path.exists('changedVideo/' + audioName + '.mp4'))):
        os.system('ffmpeg -r 44100 -i Video/' + audioName + '.mp4 changedVideo/' + audioName +'.mp4')

def convertToAudio():
    my_clip = mp.VideoFileClip(r"changedVideo/" + audioName + ".mp4")
    #my_clip.write_videofile("yolo.mp4")
    my_clip.audio.write_audiofile(r"wavFiles/" + audioName + ".wav")


changeVideo()
convertToAudio()
# extractAudioEnd-----------------------------------------------------------------------------------------


# splitAudio----------------------------------------------------------------------------------------------
fname = 'wavFiles/' + audioName + '.wav'
filename = audioName
print(filename)

# make directory
mydir = filename
parent_dir = "SplitAudio"
mode = 0o666
path = os.path.join(parent_dir, mydir)
if(os.path.isdir(path) == False):
    os.mkdir(path, mode)

# Read audio file
duration = 0
secSplit = 20
with contextlib.closing(wave.open(fname,'r')) as f:
    frames = f.getnframes()
    rate = f.getframerate()
    duration = frames / float(rate)

print("Duration:", duration)
totalPackages = math.floor(duration/secSplit + 1)
remain = math.floor((duration % secSplit) * 1000)
print("totalPackages:", totalPackages)
print("remain:", remain)


# deal with the front part
lastSplitPoint = 0
for x in range(totalPackages):
    t1 = lastSplitPoint
    t2 = lastSplitPoint + secSplit
    lastSplitPoint = t2
    t1 = t1 * 1000 #Works in milliseconds
    t2 = t2 * 1000
    newAudio = AudioSegment.from_wav(fname)
    newAudio = newAudio[t1:t2]
    newAudio.export('SplitAudio/' + filename + '/'
     + str(x) + '.wav', format="wav") #Exports to a wav file in the current path.

# deal with the remain part
t1 = lastSplitPoint
t2 = lastSplitPoint
t1 = t1 * 1000 #Works in milliseconds
t2 = t2 * 1000 + remain
newAudio = AudioSegment.from_wav(fname)
newAudio = newAudio[t1:t2]
newAudio.export('SplitAudio/'+ filename + '/' +'last.wav', format="wav") #Exports to a wav file in the current path.

# splitAudioEnd-------------------------------------------------------------------------------------------


# convertAudio--------------------------------------------------------------------------------------------

def startConvertion(path, lang): 
    with sr.AudioFile(path) as source:
        #print('Fetching File')
        audio_file = r.record(source)
        txt = r.recognize_google(audio_file, language=lang)
        print(txt)
        return txt
'''simple_text = startConvertion(path = 'SplitAudio/' + audioName + '/0.wav', lang = 'zh-TW')
simple_text += '\n'
simple_text += '\n'
simple_text += '-------------------------------------------------------------'
simple_text += startConvertion(path = 'SplitAudio/' + audioName + '/2.wav', lang = 'zh-TW')'''

#Convert all the audio to text
simple_text = ''
tmpPath = 'SplitAudio/' + audioName+ '/'
for x in range(totalPackages):
    print('number', x)
    nowpath = tmpPath + str(x) + '.wav'
    simple_text += startConvertion(path = nowpath, lang = 'zh-TW')
    simple_text += '\n'
    simple_text += '\n'


# output into txt file
with open('txt/' + audioName + '.txt', mode = 'w') as file:
    file.write("Recognized text:")
    file.write("\n")
    file.write("\n")
    file.write(simple_text)
    print("ready!")
'''from opencc import OpenCC

cc = OpenCC('s2t')

print(cc.convert(simple_text))'''


# convertAudioEnd----------------------------------------------------------------------------