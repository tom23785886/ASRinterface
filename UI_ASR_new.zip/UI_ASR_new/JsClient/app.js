// Setup basic express server
const express = require('express');
const path = require('path');
const http = require('http')
const socket = require('socket.io')
const events = require("./event");
const port = process.env.PORT || 5000; // default port: 3000
var request = require('request-promise'); // [Note]: send to python
const fs = require('fs');                 // [Note]: Save data to disk

const app = express();
const server = http.createServer(app) // use express to handle http server

const io = socket(server);
const onConnection = (socket) => {
  // Listening for joining a room (joinRoom event)
  socket.on("joinRoom", events.joinRoom(socket));
  socket.on("disconnect", () =>
    events.leaveRoom(socket)({ room: "general" })
  );

  // for peer to peer communicate
  socket.on("offer", (offer) => events.offer(socket)({room: "general", offer}));
  socket.on("answer", (answer) => events.answer(socket)({room: "general", answer}));
  socket.on("icecandidate", (candidate) => events.icecandidate(socket)({room: "general", candidate}));

  // [Note]: send to python server and get back processed data
  socket.on("image" , async function(imageData){
    var options = {
      method: 'POST',
      // http:flaskserverurl:port/route
      uri: 'http://127.0.0.1:5000/image_py',
      // uri: 'https://bdff-140-114-75-107.ngrok.io/image_py',
      body: imageData,
      // Automatically stringifies
      // the body to JSON 
      json: true
    };
    var sendrequest = await request(options)
      // The parsedBody contains the data
      // sent back from the Flask server 
      .then(function (parsedBody) {
          // console.log(parsedBody);
            
          // You can do something with
          // returned data
          let result;
          result = parsedBody['result'];
          socket.emit('response_back' , result);
      })
      .catch(function (err) {
          // console.log(err);  
      });
  });

  var DBPath = path.join(__dirname , "../../RecordData/");
  var Recfiles;

  socket.on("AskForRecFromAppJs" , function() {
    Recfiles = fs.readdirSync(DBPath);
    console.log(Recfiles)
    socket.emit("GetRecFromAppJs" , Recfiles);
  });
  
  socket.on("imageTest", async function() { 
    // This variable contains the data
    // you want to send 
    var data = {
      array: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    }

    var options = {
      method: 'POST',
      // http:flaskserverurl:port/route
      uri: 'http://127.0.0.1:5000/arraysum',
      body: data,
      // Automatically stringifies
      // the body to JSON 
      json: true
    };

    var sendrequest = await request(options)
      // The parsedBody contains the data
      // sent back from the Flask server 
      .then(function (parsedBody) {
        console.log(parsedBody);
          
        // You can do something with
        // returned data
        let result;
        result = parsedBody['result'];
        console.log("Sum of Array from Python: ", result);
        
        // [Note]: For Save Record to Disk
        // socket.emit("ArraySum" , result) // [Note]: For Method 1 & 2

        // [Note]: For Method 3
        var now = new Date(Date.now());
        fs.writeFile(DBPath + now + ".txt", "P", function(err) {
          if(err) return console.log(err);
          console.log("The file was saved!");
        });
        // // [Note]: Get path of this script
        // // [Note]: Method 1 
        // console.log(__dirname);
        // // [Note]: Method 1 
        // console.log(path.dirname());
        
      })
      .catch(function (err) {
          console.log(err);
      });
  });
};
 
io.on("connection", onConnection);
// Routing
app.use(express.static(path.join(__dirname, 'public'))); // load static resource

server.listen(port, () => {
  console.log('Server listening at port %d', port);
});