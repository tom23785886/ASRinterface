# import the module
import speech_recognition as sr
from Split import totalPackages
print(totalPackages)
#define the recognizer
r = sr.Recognizer()
audioName = 'Brain'
def startConvertion(path, lang): 
    with sr.AudioFile(path) as source:
        #print('Fetching File')
        audio_file = r.record(source)
        txt = r.recognize_google(audio_file, language=lang)
        print(txt)
        return txt
'''simple_text = startConvertion(path = 'SplitAudio/' + audioName + '/0.wav', lang = 'zh-TW')
simple_text += '\n'
simple_text += '\n'
simple_text += '-------------------------------------------------------------'
simple_text += startConvertion(path = 'SplitAudio/' + audioName + '/2.wav', lang = 'zh-TW')'''

#Convert all the audio to text
simple_text = ''
tmpPath = 'SplitAudio/' + audioName+ '/'
for x in range(totalPackages):
    print('number', x)
    nowpath = tmpPath + str(x) + '.wav'
    simple_text += startConvertion(path = nowpath, lang = 'zh-TW')
    simple_text += '\n'
    simple_text += '\n'


# output into txt file
with open('test.txt', mode = 'w') as file:
    file.write("Recognized text:")
    file.write("\n")
    file.write("\n")
    file.write(simple_text)
    print("ready!")
'''from opencc import OpenCC

cc = OpenCC('s2t')

print(cc.convert(simple_text))'''