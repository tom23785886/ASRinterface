import Chat from "./chat.js";

let peer;
let cacheStream;
//added
var globalClipName

const startButton = document.getElementById("startButton");
const callButton = document.getElementById("callButton");
const hangupButton = document.getElementById("hangupButton");

const localVideo = document.getElementById("localVideo");
const remoteVideo = document.getElementById("remoteVideo");

const offerOptions = {
  offerToReceiveAudio: 1,
  offerToReceiveVideo: 1,
};
// Media config
const mediaConstraints = {
  audio: true,
  video: true,
};

const Init = async () => {
  peer = buildPeerConnection();
  Chat.emit("joinRoom", { username: "test" });
  Chat.on("offer", (offer) => setRemoteDescription("offer", offer));
  Chat.on("answer", (answer) => setRemoteDescription("answer", answer));
  Chat.on("icecandidate", (candidate) => addCandidate(candidate));

  startButton.addEventListener("click", getUserStream);
  callButton.addEventListener("click", caller);
  hangupButton.addEventListener("click", close);
};

function buildPeerConnection() {
  const peer = new RTCPeerConnection();
  peer.onicecandidate = onIceCandidate;
  peer.ontrack = addRemoteStream;

  return peer;
}

function onIceCandidate(event) {
  Chat.emit("icecandidate", event.candidate);
}

function addRemoteStream(event) {
  if (remoteVideo.srcObject !== event.streams[0]) {
    remoteVideo.srcObject = event.streams[0];

    // // [Note]: Audio Record (Remote)
    AudioRecord(event.streams[0]);
  }
}

// [Note]: show processed video(actually image)
var canvas = document.getElementById('canvas');
var context = canvas.getContext('2d');

// [Note]: Decide whether to take segment
var greybtn = document.getElementById('grey');
var doGrey = 0;
greybtn.onclick = function() {   
    if(doGrey == 0) doGrey = 1;
    else doGrey = 0;
}

async function getUserStream() {
  console.log("Requesting local stream");
  if ("mediaDevices" in navigator) {
    const stream = await navigator.mediaDevices.getUserMedia(
      mediaConstraints
    );
    cacheStream = stream;
    localVideo.srcObject = stream;
    stream.getTracks().forEach((track) => peer.addTrack(track, stream));

    // [Note]: enable button -> 1. audio record  2. Grey
    record.disabled = false;
    stop.disabled = false;
    greybtn.disabled = false;
    recordPage.disabled = true;

    // [Note]: send to app.js (and then send to python server)
    localVideo.width = 400;
    localVideo.height = 300; 
    localVideo.play();
    const FPS = 6;
    
    // // [Note]: hide Video & canvas
    // localVideo.style.display = "none";
    // canvas.style.display = "none";

    // [Note]: Audio Record (Local)
    AudioRecord(stream);

    // [Note]: Test (Can Delete)
    Chat.emit("imageTest");
    
    // [Note]: Save Record to Disk (Method 1 & 2)
    function Save() {
      // // [Note]: Save Record to Disk (Method 1)
      // Chat.on("ArraySum" , function(sum) {
      //   console.log("Before Save");

      //   var textToSave = sum;
      //   var hiddenElement = document.createElement('a');

      //   hiddenElement.href = 'data:attachment/text,' + encodeURI(textToSave);
      //   hiddenElement.target = '_blank';
      //   hiddenElement.download = 'myFile.txt';
      //   // hiddenElement.click();
      //   hiddenElement.remove();

      //   console.log("After Save");
      // });
      // // [Note]: Save Record to Disk (Method 2)
      // Chat.on("ArraySum" , function(sum) {
      //   console.log("Before Save");

      //   var blob = new Blob(["Welcome to Websparrow.org."],
      //             { type: "text/plain;charset=utf-8" });
      //   saveAs(blob, "static.txt");
      //   // localStorage.setItem("myBlob", blob);

      //   console.log("After Save");
      // });
    }
    // [Note]: Save Record to Disk (Method 3) => Use "fs" in app.js

    // [Note]: send video data to app.js
    setInterval(() => {
        var width=localVideo.width;
        var height=localVideo.height;

        context.drawImage(localVideo, 0, 0, width , height);
        var data = canvas.toDataURL('image/jpeg', 0.5);
        
        context.clearRect(0, 0, width,height );
        
        Chat.emit('image', {image: data , dogrey: doGrey});
    }, 1000/FPS);

    Chat.on('response_back', function(image){
      photo.setAttribute('src', image);     
    });
  }
}
// [Note]: record function
const record = document.getElementById('record'); 
const stop = document.getElementById('stopRec');
const recordPage = document.getElementById('recordPage');
const soundClips = document.querySelector('.sound-clips');
let mediaRecorder = [];

// [Note]: Route to Record Page
recordPage.onclick = function() {
  //window.location.href = "../html/Record.html";
  //added
  console.log('clipName:', globalClipName);
  var a = document.createElement('a');
  a.href = 'http://127.0.0.1:5000/getClipName/' + globalClipName
  a.click();
  //added
}

// [Note]: record function
function AudioRecord(stream) {
  const sub_mediaRecorder = new MediaRecorder(stream);
  mediaRecorder.push(sub_mediaRecorder);

  // record.addEventListener('onclick' , function() {})
  record.onclick = function () {
      // [Note]: do audio record for each user 
      mediaRecorder.forEach(element => {
        element.start();
        console.log(element.state);
      })
      console.log("recorder started");
      record.style.background = "red";
      record.style.color = "black";
  }
  let chunks = [];

  mediaRecorder.forEach(element => element.ondataavailable = function(e) {
    chunks[element] = [];
    chunks[element].push(e.data);
    // console.log(e.data);
    console.log(chunks[element]);
  })
  stop.onclick = function() {
      // [Note]: do audio record for each user 
      mediaRecorder.forEach(element => {
        element.stop();
        console.log(element.state);
      })
      // [Note]: Orignial Code
      // mediaRecorder.stop();
      // console.log(mediaRecorder.state);
      console.log("recorder stopped");
      record.style.background = "";
      record.style.color = "";
  }
  mediaRecorder.forEach(element => element.onstop = function(e) {
    console.log("recorder stopped");

    const clipName = prompt('Enter a name for your sound clip');

    const clipContainer = document.createElement('article');
    const clipLabel = document.createElement('p');
    const audio = document.createElement('audio');
    // const audio = document.createElement('video');
    const deleteButton = document.createElement('button');

    clipContainer.classList.add('clip');
    audio.setAttribute('controls', '');
    deleteButton.innerHTML = "Delete";
    clipLabel.innerHTML = clipName;
    console.log("Name of Clip: ", clipName)

    clipContainer.appendChild(audio);
    clipContainer.appendChild(clipLabel);
    clipContainer.appendChild(deleteButton);
    soundClips.appendChild(clipContainer);

    // const blob = new Blob(chunks, { 'type' : 'audio/ogg; codecs=opus' });
    // const blob = new Blob(chunks, { type: mediaRecorder.mimeType });
    // console.log(chunks[0].type)  // original code
    console.log(chunks[element].type , ' Cool')
    // const blob = new Blob(chunks, { type: chunks[0].type });
    const blob = new Blob(chunks[element], { 'type' : 'video/mp4' });
    chunks[element] = [];
    const audioURL = window.URL.createObjectURL(blob);
    audio.src = audioURL;

    //added
    var a = document.createElement('a');
    a.href = audioURL;
    a.download = clipName;
    a.click();
    globalClipName = clipName;
    //added
    

    deleteButton.onclick = function(e) {
        let evtTgt = e.target;
        evtTgt.parentNode.parentNode.removeChild(evtTgt.parentNode);
    }
  })
}

async function caller() {
  try {
    console.log("createOffer start");
    const offer = await peer.createOffer(offerOptions);
    await peer.setLocalDescription(offer);
    sendSDPBySignaling("offer", offer);
  } catch (error) {
    console.log(`Failed to create session description: ${error.toString()}`);
  }
}

async function setRemoteDescription(type, desc) {
  try {
    console.log(type, desc)
    await peer.setRemoteDescription(desc);
    if (type === "offer") createAnswer();
  } catch (error) {
    console.log(`Failed to create session description: ${error.toString()}`);
  }
}
async function createAnswer () {
  try {
    console.log("create answer");
    const answer = await peer.createAnswer();
    await peer.setLocalDescription(answer);
    sendSDPBySignaling("answer", answer);
  } catch (e) {
    onSetSessionDescriptionError(e);
  }
}

function addCandidate(candidate) {
  try {
    peer.addIceCandidate(candidate);
  } catch (error) {
    console.log(`Failed to add ICE: ${error.toString()}`);
  }
}

function sendSDPBySignaling(event, sdp) {
  console.log(event, sdp)
  Chat.emit(event, sdp);
}

function close() {
  // [Note]: disable button -> 1. audio record  2. Grey
  record.disabled = true;
  stop.disabled = true;
  greybtn.disabled = true;
  recordPage.disabled = false;

  peer.close();
  peer = null;
  cacheStream.getTracks().forEach((track) => track.stop());
}

Init().catch((err) => console.log(err));
