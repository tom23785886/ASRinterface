// [Note]: Another Method: Use <a> href
import Chat from "./chat.js";

const backbtn = document.getElementById('backToHome');

// [Note]: method 1 
// backbtn.addEventListener('click' , Back);
// function Back() {
//     window.location.href = "../index.html";
// }

// [Note]: Method 
backbtn.onclick = function() {
    window.location.href = "../index.html";
}

// [Note]: Main Contain for this Page
var RecFileNames;
const videoRec = document.querySelector('.video-record');

window.onload = function() {
    console.log("Page Loaded");

    // [Note]: Trigger app.js and get record files name list
    Chat.emit("AskForRecFromAppJs")
    Chat.on("GetRecFromAppJs" , function(files){
        RecFileNames = files;
        console.log("Get!!!!!");
        CreateRecordFileElement(files);
    });
    
}

function CreateRecordFileElement(fileNames) {
    fileNames.forEach(fileName => {
        const OneRecSection = document.createElement('section');
        const OneRecVideoName = document.createElement('p');
        const OneRecVideo = document.createElement('video');

        OneRecVideoName.innerHTML = fileName;

        OneRecSection.appendChild(OneRecVideoName);
        
        videoRec.appendChild(OneRecSection);
    });
}

